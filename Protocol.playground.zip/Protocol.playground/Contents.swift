import UIKit

protocol MyProtocol {
    var degisken:Int {get set}
    
    func metod1()
    func metod2() -> String
}
class ClassA : MyProtocol { //burada MyProtocol yanına virgül koyarak birden fazla protokol ismini de classA içerisine ekleyebiliriz, katılımdan bir farkı olarak da öne çıkar.
    var degisken: Int = 10
    func metod1() {
    print ("Metod 1 çalıştı")
    }
    func metod2() -> String {
        return "Metod 2 çalıştı"
    }
}

var a = ClassA()
print(a.degisken)

a.metod1()
print(a.metod2())
